1) Add hangman ASCII art, which will add a body part every time the player guesses a letter wrong.
  Feel free to use this template:
      print("  +---+")
      print("  |   |")
      print("  O   |")
      print(" /|\  |")
      print(" / \  |")
      print("      |")
      print("=========")

2) Create a function that will assign a new word to the player and restart the game

**Bonus: Add a function that pulls words from online instead of the word.txt file
  Here is a link you can use: https://www.mit.edu/~ecprice/wordlist.10000 